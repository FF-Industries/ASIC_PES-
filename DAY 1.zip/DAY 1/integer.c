#include <stdio.h>
#include <math.h>
#include <limits.h>

int main() {
    unsigned long long int max_unsigned = (unsigned long long int) (pow(2, 64) - 1);
    unsigned long long int min_unsigned = 0;

    printf("Unsigned 64-bit Integer Range:\n");
    printf("Lowest number: %llu\n", min_unsigned);
    printf("Highest number: %llu\n\n", max_unsigned);

    long long int max_signed = (long long int) (pow(2, 63) - 1);
    long long int min_signed = -((long long int) pow(2, 63)); 

    printf("Signed 64-bit Integer Range:\n");
    printf("Lowest number: %lld\n", min_signed);
    printf("Highest number: %lld\n", max_signed);

    return 0;
}


