#include <stdio.h>

int main() {
    int N=10, sum = 0;
    for (int i = 1; i <= N; i++)
    {
        sum += i;
    }

    printf("Sum from 1 to %d is: %d\n", N, sum);

    return 0;
}
